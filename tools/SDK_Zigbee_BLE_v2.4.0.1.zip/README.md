# telink_zigbee_ble_concurrent_sdk

zigbee+ble concurrent mode for 8258